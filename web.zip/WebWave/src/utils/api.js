export const products = [
  {
    _id: "1",
    name: "Wireless Headphones",
    image: "https://picsum.photos/seed/headphones/600/400",
    description:
      "High-quality sound with noise isolation. Perfect for music lovers.",
    price: 89.99,
  },
  {
    _id: "2",
    name: "Smartwatch Series X",
    image: "https://picsum.photos/seed/watch/600/400",
    description:
      "Track your steps, heart rate, and notifications with premium accuracy.",
    price: 129.99,
  },
  {
    _id: "3",
    name: "Gaming Keyboard",
    image: "https://picsum.photos/seed/keyboard/600/400",
    description:
      "RGB mechanical keys with fast response for gamers and creators.",
    price: 59.99,
  },
  {
    _id: "4",
    name: "4K Action Camera",
    image: "https://picsum.photos/seed/camera/600/400",
    description:
      "Waterproof, ultra-wide lens, and 4K UHD recording for adventures.",
    price: 149.99,
  },
  {
    _id: "5",
    name: "Bluetooth Speaker",
    image: "https://picsum.photos/seed/speaker/600/400",
    description:
      "Powerful bass and HD sound. Compact and lightweight for travel.",
    price: 39.99,
  },
];
