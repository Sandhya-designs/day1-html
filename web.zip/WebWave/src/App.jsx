import React from "react";
import { Routes, Route } from "react-router-dom";
import Products from "./components/Products";
import ProductDetails from "./components/ProductDetails";
import NavBar from "./components/NavBar";

export default function App() {
  return (
    <>
      <NavBar />

      <div className="container mx-auto p-6">
        <Routes>
          <Route path="/" element={<Products />} />
          <Route path="/product/:id" element={<ProductDetails />} />
        </Routes>
      </div>
    </>
  );
}

