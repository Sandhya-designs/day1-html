import React from "react";
import { Link } from "react-router-dom";

export default function NavBar() {
  return (
    <nav className="bg-white shadow p-4">
      <div className="container flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">
          MyShop
        </Link>

        <div className="flex gap-4">
          <Link to="/" className="hover:text-indigo-600">
            Home
          </Link>
          <Link to="/cart" className="hover:text-indigo-600">
            Cart
          </Link>
        </div>
      </div>
    </nav>
  );
}
