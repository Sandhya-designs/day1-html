import React from "react";
import { Link } from "react-router-dom";

export default function ProductCard({ product }) {
  return (
    <div className="bg-white rounded shadow p-4">
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-48 object-cover rounded"
      />

      <h2 className="font-semibold text-lg mt-3">{product.name}</h2>

      <p className="text-gray-600 text-sm mt-1 line-clamp-2">
        {product.description}
      </p>

      <div className="flex items-center justify-between mt-4">
        <span className="font-bold text-lg">₹{product.price}</span>

        <Link
          to={`/product/${product._id}`}
          className="px-3 py-1 bg-indigo-600 text-white rounded text-sm"
        >
          View
        </Link>
      </div>
    </div>
  );
}
