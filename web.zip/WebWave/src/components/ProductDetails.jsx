import React from "react";
import { useParams } from "react-router-dom";
import { products } from "../utils/api";

export default function ProductDetails() {
  const { id } = useParams();
  const product = products.find((p) => p._id === id);

  if (!product) return <h2>Product not found</h2>;

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 rounded shadow">
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-80 object-cover rounded"
      />

      <h1 className="text-3xl font-bold mt-4">{product.name}</h1>

      <p className="text-gray-700 mt-3 text-lg">{product.description}</p>

      <div className="mt-5 text-2xl font-bold">₹{product.price}</div>

      <button className="mt-6 bg-indigo-600 text-white px-4 py-2 rounded">
        Add to Cart
      </button>
    </div>
  );
}
